#!/usr/bin/env node

// Azure deployment entry point with simplified engine loading
import('./src/server-azure.js').catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});