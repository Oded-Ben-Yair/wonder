const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 5050;

// CORS configuration
app.use(cors({
  origin: [
    'https://delightful-water-0728cae03.1.azurestaticapps.net',
    'http://localhost:3000',
    'http://localhost:5173'
  ],
  credentials: true
}));

app.use(express.json());

// Sample nurses data
const nursesData = [
  {
    id: 'nurse-001',
    name: 'Sarah Johnson',
    city: 'Tel Aviv',
    services: ['Wound Care', 'Medication Management', 'General Care'],
    lat: 32.0853,
    lng: 34.7818,
    rating: 4.8,
    reviewsCount: 127,
    availability: {
      '2025-09-16': ['09:00-12:00', '14:00-18:00'],
      '2025-09-17': ['09:00-12:00', '14:00-18:00']
    }
  },
  {
    id: 'nurse-002',
    name: 'Michael Cohen',
    city: 'Tel Aviv',
    services: ['Pediatric Care', 'General Care'],
    lat: 32.0753,
    lng: 34.7718,
    rating: 4.9,
    reviewsCount: 89,
    availability: {
      '2025-09-16': ['08:00-16:00'],
      '2025-09-17': ['08:00-16:00']
    }
  },
  {
    id: 'nurse-003',
    name: 'Rachel Levy',
    city: 'Haifa',
    services: ['Wound Care', 'Geriatric Care'],
    lat: 32.7940,
    lng: 34.9896,
    rating: 4.7,
    reviewsCount: 203,
    availability: {
      '2025-09-16': ['10:00-14:00', '16:00-20:00'],
      '2025-09-17': ['10:00-14:00', '16:00-20:00']
    }
  },
  {
    id: 'nurse-004',
    name: 'David Mizrahi',
    city: 'Beer Sheba',
    services: ['Emergency Care', 'General Care'],
    lat: 31.2530,
    lng: 34.7915,
    rating: 4.6,
    reviewsCount: 156,
    availability: {
      '2025-09-16': ['24/7'],
      '2025-09-17': ['24/7']
    }
  }
];

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    ok: true,
    timestamp: new Date().toISOString(),
    service: 'wonder-gateway',
    nursesLoaded: nursesData.length
  });
});

// List engines endpoint
app.get('/engines', (req, res) => {
  res.json({
    engines: [
      {
        name: 'engine-basic',
        healthy: true,
        url: 'internal',
        description: 'Basic filtering engine'
      }
    ]
  });
});

// Match endpoint
app.post('/match', (req, res) => {
  const { city, servicesQuery, topK = 5 } = req.body;
  
  let results = [...nursesData];
  
  // Filter by city
  if (city) {
    results = results.filter(nurse => 
      nurse.city.toLowerCase().includes(city.toLowerCase())
    );
  }
  
  // Filter by services
  if (servicesQuery && servicesQuery.length > 0) {
    results = results.filter(nurse =>
      servicesQuery.some(service =>
        nurse.services.some(ns => 
          ns.toLowerCase().includes(service.toLowerCase())
        )
      )
    );
  }
  
  // Limit results
  results = results.slice(0, topK).map(nurse => ({
    id: nurse.id,
    name: nurse.name,
    score: nurse.rating / 5,
    reason: `Matches criteria in ${nurse.city}`,
    nurse: {
      ...nurse,
      nurseId: nurse.id,
      specialization: nurse.services,
      municipality: [nurse.city],
      isActive: true,
      isApproved: true
    }
  }));
  
  res.json({
    results,
    engine: 'engine-basic',
    latency_ms: Math.round(Math.random() * 100 + 50),
    query: req.body,
    total_results: results.length
  });
});

// Azure OpenAI endpoint (if needed)
app.post('/azure-openai', async (req, res) => {
  if (process.env.AZURE_OPENAI_KEY && process.env.AZURE_OPENAI_ENDPOINT) {
    try {
      const response = await axios.post(
        process.env.AZURE_OPENAI_ENDPOINT,
        req.body,
        {
          headers: {
            'api-key': process.env.AZURE_OPENAI_KEY,
            'Content-Type': 'application/json'
          }
        }
      );
      res.json(response.data);
    } catch (error) {
      res.status(500).json({ error: 'Azure OpenAI request failed' });
    }
  } else {
    res.status(503).json({ error: 'Azure OpenAI not configured' });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Gateway API running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});