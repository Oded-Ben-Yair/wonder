// Hebrew names generator for nurses
const hebrewFemaleNames = [
  'שרה', 'רבקה', 'רחל', 'לאה', 'מרים', 'אסתר', 'רות', 'נעמי', 'חנה', 'דבורה',
  'יעל', 'תמר', 'מיכל', 'אביגיל', 'איילת', 'נועה', 'שירה', 'ליאת', 'אורית', 'גלית',
  'דנה', 'מאיה', 'ענת', 'סיגל', 'אילנה', 'יונית', 'רונית', 'שושנה', 'אירית', 'נורית',
  'טלי', 'מור', 'ליאור', 'עדי', 'שני', 'הילה', 'ורד', 'כרמל', 'אלונה', 'נטלי',
  'יסמין', 'עינב', 'רעות', 'הדס', 'אפרת', 'בת-שבע', 'צילה', 'פנינה', 'זהבה', 'ברכה'
];

const hebrewMaleNames = [
  'דוד', 'משה', 'אברהם', 'יעקב', 'יצחק', 'יוסף', 'בנימין', 'שמואל', 'אליהו', 'דניאל',
  'נתן', 'יונתן', 'אורי', 'עידו', 'גיל', 'רון', 'איתן', 'ארז', 'עומר', 'אסף'
];

const hebrewLastNames = [
  'כהן', 'לוי', 'מזרחי', 'פרץ', 'ביטון', 'אברהם', 'פרידמן', 'גולדברג', 'דוד', 'אזולאי',
  'חדד', 'כץ', 'ברוך', 'אוחיון', 'אדרי', 'דהן', 'גבאי', 'שטרן', 'שפירא', 'ויצמן',
  'בן דוד', 'בן חיים', 'בן שמעון', 'בן אברהם', 'בן יוסף', 'בן משה', 'גרינברג', 'רוזנברג', 'קפלן', 'שוורץ'
];

function generateHebrewName(index, isMale = false) {
  const firstNames = isMale ? hebrewMaleNames : hebrewFemaleNames;
  const firstName = firstNames[index % firstNames.length];
  const lastName = hebrewLastNames[index % hebrewLastNames.length];
  return `${firstName} ${lastName}`;
}

module.exports = { generateHebrewName };